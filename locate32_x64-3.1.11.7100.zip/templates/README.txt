This directory file contains template files for Locate32. Currently only 
template files can only be used with "Save Results" feature. 

1. "Save results" template files (extention: RET)

These template files can be used with "Save Results" command to 
save results to a HTML file using custom layout. Currently (in RC2)
the format is restricted and allows only to format quite simple 
layouts similar to the standard layout used with "Save results". 
In future, the format will be improved to, for example, provide support
for thumbnail extraction (e.g., to create results pages similar to photo 
albums).

For an example, see existing ret files. 